"""
Test package for ecommerce API.
"""
